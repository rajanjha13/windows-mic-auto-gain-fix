Mic Volume Guard ZIP Usage

1) Extract this ZIP to a folder.
2) Run START-MicVolumeGuard.cmd (recommended).
3) If Windows still blocks it, right click MicVolumeGuard.exe -> Properties -> Unblock.
