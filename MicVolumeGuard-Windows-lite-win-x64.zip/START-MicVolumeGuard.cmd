@echo off
setlocal
cd /d "%~dp0"

echo Starting MicVolumeGuard...
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Get-Item '.\\MicVolumeGuard.exe' -Stream Zone.Identifier -ErrorAction SilentlyContinue) { Unblock-File '.\\MicVolumeGuard.exe' }" >nul 2>&1

start "" ".\\MicVolumeGuard.exe"
if errorlevel 1 (
    echo.
    echo Could not start MicVolumeGuard.exe.
    echo Right click MicVolumeGuard.exe, open Properties, and click Unblock.
    pause
)
